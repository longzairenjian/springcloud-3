package com.onemo.email.service;

public interface EmailService {

    /**
     * 向指定的邮箱发送验证码
     * @param email 邮箱账号
     * @param code 验证码
     * @return true 发送成功 false 发送失败
     */
    boolean send(String email, String code);
}
