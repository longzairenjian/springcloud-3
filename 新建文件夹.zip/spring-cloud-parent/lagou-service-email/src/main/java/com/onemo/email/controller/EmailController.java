package com.onemo.email.controller;

import com.onemo.common.module.ResultData;
import com.onemo.common.utils.ResultDataUtils;
import com.onemo.email.service.EmailService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


@RestController
@RequestMapping("api/email")
public class EmailController {

    @Resource
    private EmailService emailService;

    @Value("${mysql.datasource.url}")
    private String url;

    @GetMapping("view")
    public String view() {
        return "===>url:" + url;
    }


    @GetMapping("/{email}/{code}")
    public ResultData<Boolean> send(@PathVariable("email") String email, @PathVariable("code") String code) {
        return ResultDataUtils.create(emailService.send(email, code));
    }
}
