package com.onemo.feign;

import com.onemo.common.module.ResultData;
import com.onemo.feign.hystrix.CodeClientHystrix;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "lagou-service-code", fallback = CodeClientHystrix.class, path = "/api/code/")
public interface CodeClient {

    /**
     * ⽣成验证码并发送到对应邮箱，成功true，失败false
     *
     * @param email 邮箱账号
     * @return true 成功 false 失败
     */
    @GetMapping("create/{email}")
    ResultData<Boolean> create(@PathVariable("email") String email);


    /**
     * 校验验证码是否正确，0正确1错误2超时
     *
     * @param email 邮箱账号
     * @param code  验证码
     */
    @GetMapping("validate/{email}/{code}")
    ResultData<Integer> validate(@PathVariable("email") String email, @PathVariable("code") String code);

}
