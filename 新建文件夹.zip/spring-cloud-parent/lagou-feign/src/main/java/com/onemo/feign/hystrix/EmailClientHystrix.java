package com.onemo.feign.hystrix;

import com.onemo.common.module.ResultData;
import com.onemo.feign.EmailClient;
import org.springframework.stereotype.Component;

@Component
public class EmailClientHystrix implements EmailClient {
    @Override
    public ResultData<Boolean> send(String email, String code) {
        return null;
    }
}
