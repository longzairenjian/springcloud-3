package com.onemo.feign;

import com.onemo.common.module.ResultData;
import com.onemo.feign.hystrix.EmailClientHystrix;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "lagou-service-email", fallback = EmailClientHystrix.class, path = "/api/email/")
public interface EmailClient {

    @GetMapping("/{email}/{code}")
    ResultData<Boolean> send(@PathVariable("email")String email, @PathVariable("code") String code);
}
