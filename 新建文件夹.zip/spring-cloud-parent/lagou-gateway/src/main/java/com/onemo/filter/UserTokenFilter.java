package com.onemo.filter;


import com.alibaba.fastjson.JSON;
import com.onemo.common.utils.ResultDataUtils;
import com.onemo.common.utils.TokenUtil;
import com.onemo.config.LagouConfigProperties;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.annotation.Resource;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 验证当前用户是否登录
 */
@Component
public class UserTokenFilter implements GlobalFilter, Ordered {


    private static final String TOKEN = "token";

    @Resource
    private LagouConfigProperties lagouConfigProperties;


    @Override

    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();
        MultiValueMap<String, HttpCookie> cookies = request.getCookies();
        List<HttpCookie> tokens = cookies.get(TOKEN);
        if (CollectionUtils.isNotEmpty(tokens)) {
            for (HttpCookie token : tokens) {
                if (TOKEN.equals(token.getName())) {
                    if (TokenUtil.verify(token.getValue())) {
                        return chain.filter(exchange);
                    }
                }
            }
        }
        //如果当前是登录接口 注册接口 则可以通过
        List<String> urls = lagouConfigProperties.getUrls();
        if (CollectionUtils.isNotEmpty(urls)) {
            String path = request.getURI().getPath();
            //匹配排除的接口路径  匹配成功则代表当前接口不需要校验token
            if (urls.stream().anyMatch(a -> Pattern.matches(".*" + a + ".*", path))) {
                return chain.filter(exchange);
            }
        }
        //当前用户未登录 返回未登录信息
        DataBuffer wrap = response.bufferFactory().wrap(JSON.toJSONString(ResultDataUtils.createNeedLogin()).getBytes());
        return response.writeWith(Mono.just(wrap));
    }

    @Override
    public int getOrder() {
        return 0;
    }

}
