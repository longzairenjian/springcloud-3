package com.onemo.filter;

import com.alibaba.fastjson.JSON;
import com.onemo.common.utils.ResultDataUtils;
import com.onemo.config.IpBlackProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.annotation.Resource;
import java.net.InetSocketAddress;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

@Component
@Slf4j
public class IPBlackFilter implements GlobalFilter, Ordered {


    @Resource
    private RedisTemplate<String, Integer> redisTemplate;

    @Resource
    private IpBlackProperties ipBlackProperties;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();
        List<IpBlackProperties.IpBlack> interfacePaths = ipBlackProperties.getInterfacePaths();
        InetSocketAddress remoteAddress = request.getRemoteAddress();
        if (CollectionUtils.isNotEmpty(interfacePaths) && Objects.nonNull(remoteAddress)) {
            String clientIp = remoteAddress.getHostString();
            log.info("====》当前访问的ip地址是:{}", clientIp);
            String interfacePath = request.getURI().getPath();
            for (IpBlackProperties.IpBlack path : interfacePaths) {
                if (Pattern.matches(".*" + path.getInterfacePath() + ".*", interfacePath)) {
                    String key = buildKey(clientIp, path.getInterfacePath());
                    Integer count = redisTemplate.opsForValue().get(key);
                    if (Objects.nonNull(count) && count >= 0) {
                        count++;
                        if (count > path.getCount()) {
                            //当前用户未登录 返回未登录信息
                            DataBuffer wrap = response.bufferFactory().wrap(JSON.toJSONString(ResultDataUtils.createError("303", "您的操作过于频繁，请求已被拒绝")).getBytes());
                            return response.writeWith(Mono.just(wrap));
                        }
                        //此处设置偏移量为0 即对应Redis命令为SETRANGE 不会重置过期时间
                        redisTemplate.opsForValue().set(key, count, 0);
                    } else {
                        //保存该客户端ip访问了该接口一次 并且有效时间是一分钟 一分钟后自动重新计算
                        redisTemplate.opsForValue().set(key, 1, path.getTime(), TimeUnit.SECONDS);
                    }
                    break;
                }
            }
        }
        return chain.filter(exchange);
    }


    private String buildKey(String clientIp, String interfacePath) {
        return clientIp + ":" + interfacePath;
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
