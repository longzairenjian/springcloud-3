package com.onemo.code.service;

public interface CodeService {

    boolean create(String email);


    Integer validate(String email, String code);
}
