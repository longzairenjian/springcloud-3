package com.onemo.common.module;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResultData<T> {

    /**
     * 响应码
     */
    private String code;
    /**
     * 响应消息
     */
    private String message;
    /**
     * 响应结果
     */
    private T result;
}
