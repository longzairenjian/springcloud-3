package com.onemo.common.exception;

import lombok.Getter;

@Getter
public class LagouCloudException extends RuntimeException{

    private String code;

    private final String errorMsg;

    public LagouCloudException(String message) {
        super(message);
        this.errorMsg = message;
    }

    public LagouCloudException(String code, String errorMsg) {
        super(errorMsg);
        this.code = code;
        this.errorMsg = errorMsg;
    }
}
