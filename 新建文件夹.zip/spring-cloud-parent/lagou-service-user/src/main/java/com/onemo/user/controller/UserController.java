package com.onemo.user.controller;

import com.onemo.common.module.ResultData;
import com.onemo.common.utils.ResultDataUtils;
import com.onemo.user.service.UserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("api/user")
public class UserController {

    @Resource
    private UserService userService;

    /**
     *
     * @param email    邮箱
     * @param password 密码
     * @return 返回用户邮箱
     */
    @GetMapping("login/{email}/{password}")
    public ResultData<String> login(@PathVariable("email") String email, @PathVariable("password") String password) {
        return ResultDataUtils.create(userService.login(email, password));
    }


    /**
     * 注册接⼝，true成功，false失败
     *
     * @param email    邮箱
     * @param password 密码
     * @param code     验证码
     */
    @GetMapping("register/{email}/{password}/{code}")
    public ResultData<Boolean> register(@PathVariable("email") String email, @PathVariable("password") String password, @PathVariable("code") String code) {
        return ResultDataUtils.create(userService.register(email, password, code));
    }


    /**
     * 是否已注册，根据邮箱判断,true代表已经注册过，false代表尚未注册
     *
     * @param email 邮箱
     */
    @GetMapping("isRegistered/{email}")
    public ResultData<Boolean> login(@PathVariable("email") String email) {
        return ResultDataUtils.create(userService.isRegister(email));
    }


    /**
     * 根据token查询⽤户登录邮箱接⼝
     *
     * @param token 用户token
     */
    @GetMapping("info/{token}")
    public ResultData<String> info(@PathVariable("token") String token) {
        return ResultDataUtils.create(userService.userInfo(token));
    }
}
