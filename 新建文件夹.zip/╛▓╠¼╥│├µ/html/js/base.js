/**
 * Created by ws on 2020/8/25.
 */
window.apipath={}; 
window.apipath.registerUser="/user/register";
window.apipath.hasRegisteredUser="/user/isRegistered";
window.apipath.createCode="/code/create/";
window.apipath.loginUser="/user/login";
window.apipath.currentUser="/user/info";